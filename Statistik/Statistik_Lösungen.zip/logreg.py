import numpy as np
import math
from random import choice

labels = (0, 1, 2)
label_names = {'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2}

def read_data_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as data:
        documents = [line.split(",") for line in data.read().split("\n") if line != ""]         #data.readlines()?
    return documents

def get_vectors(data):
    return [([float(x) for x in example[:-1]], label_names[example[-1]]) for example in data]

def phi(training_example, label):
    fluff = [0] * len(training_example)
    pump_dict = {0: training_example + 2 * fluff, 1: fluff + training_example + fluff, 2: 2 * fluff + training_example}
    return np.array(pump_dict[label])

def prob(training_example, weights, label):
    z = 0
    for l in labels:
        z += math.exp(np.dot(weights, phi(training_example[0], l)))
        print(z)
    return math.exp(np.dot(weights, phi(training_example[0], label))) / z

def log_reg_online(training_data, epochs = 2000, learning_rate = 0.1):
    weights = np.zeros(len(training_data[0][0]) * len(labels))

    for _ in range(1, epochs):
        for t in training_data:
            example = choice(training_data)
            s = [0] * len(weights)
            for label in labels:
                s = np.add(s, prob(example, weights, label) * phi(example[0], label))

            weights = weights + learning_rate * (phi(example[0], example[1]) - s)

    print(weights)
    return weights

def log_reg_batch(training_data, epochs = 2000, learning_rate = 0.1):
    weights = np.zeros(len(training_data[0][0]) * len(labels))

    batch_gradient = [0] * len(weights)

    for n in range(1, epochs):
        for t in training_data:
            s = [0] * len(weights)
            s = np.subtract(s, phi(t[0], t[1]))
            for label in labels:
                s = np.add(s, prob(t, weights, label) * phi(t[0], label))

            batch_gradient = batch_gradient + learning_rate * s

        weights = weights - batch_gradient / (len(training_data) * n)

    print(weights)
    return weights

def log_reg_averaged(training_data, epochs = 2000, learning_rate = 0.1):
    weights = np.zeros(len(training_data[0][0]) * len(labels))
    weights_list = [weights]

    for n in range(1, epochs):
        for t in training_data:
            s = [0] * len(weights)
            for label in labels:
                s = np.add(s, prob(t, weights, label) * phi(t[0], label))
            weights = weights + learning_rate * (phi(t[0], t[1]) - s)
            weights_list.append(weights)

    print(np.sum(weights_list, 0) / (epochs * len(training_data)))
    return np.sum(weights_list, 0) / (epochs * len(training_data))

def label_max_score(t, weights):
    dict = {}
    for label in labels:
        dict[np.dot(weights, phi(t, label))] = label
    return dict[max(dict.keys())]

def accuracy(weights, test_data):
    correctly_labeled = 0
    for t in test_data:
        if label_max_score(t[0], weights) == t[1]:
            correctly_labeled += 1
    return correctly_labeled / len(test_data)

if __name__ == "__main__":
    d = read_data_from_file("iris.data")

    data = get_vectors(d)
    training_data = []
    test_data = []

    for i in range(len(data)):
        if i % 5 == 0:
            test_data.append(data[i])
        else:
            training_data.append(data[i])

#print(accuracy(log_reg_online(training_data), test_data))                #0.9666666666666667
print(accuracy(log_reg_batch(training_data), test_data))                #0.9666666666666667
#print(accuracy(log_reg_averaged(training_data), test_data))                #0.9666666666666667

#The weights are different, but the accuracy on the test set remains the same.
'''
[  8.37971839  13.24090069 -18.32936218 -10.24679085   9.01694693
   3.11186374  -6.73522313 -14.4475219  -17.39666532 -16.35276443
  25.0645853   24.69431275]
0.9666666666666667
[ 1.74642092  3.796568   -4.92354847 -2.31730171  2.06159958 -0.07811465
 -1.11774067 -2.46332566 -3.8080205  -3.71845335  6.04128914  4.78062737]
0.9666666666666667
[  7.0939865   10.3260259  -14.3597426   -7.7824209    7.50676748
   5.49559615  -7.09171927 -14.11928386 -14.60075399 -15.82162205
  21.45146187  21.90170476]
0.9666666666666667
'''