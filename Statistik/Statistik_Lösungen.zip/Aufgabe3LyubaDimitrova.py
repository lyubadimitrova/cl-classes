# -*- coding: utf-8 -*-
"""

@author: Lyubomira Dimitrova

"""
import sys
import re

def read_corpus_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as corpus:
        documents = [sent.split("\t") for sent in corpus.read().split("\n") if sent != ""]
    return documents    


def count_term(term, document):
    return len(re.findall(term, document))


def naive_bayes(document_vectors, terms):
    positive_docs = []
    negative_docs = []
    
    for doc in document_vectors:
        if doc[-1] == "+":
            positive_docs.append(doc[:-1])
            
        else:
            negative_docs.append(doc[:-1])
    
    number_pos_docs = len(positive_docs)
    number_neg_docs = len(negative_docs)
    
    pos_vector = sum_list_of_vectors(positive_docs)
    neg_vector = sum_list_of_vectors(negative_docs)
    
    return (pos_vector, number_pos_docs), (neg_vector, number_neg_docs), len(document_vectors), len(terms)


def predict(test_vector, document_vectors, terms, smoothing):
    
    model = naive_bayes(document_vectors, terms)
    docs_pos = model[0]
    docs_neg = model[1]
    docs_all = model[2]
    vocabulary = model[3]
    
    terms_in_pos_docs = field_sum(docs_pos[0])
    terms_in_neg_docs = field_sum(docs_neg[0])
    
    if smoothing == True:
        
        probability_pos = docs_pos[1]/docs_all
        
        for i in range(len(test_vector)-1):
            if test_vector[i] > 0:
                probability_pos *= (docs_pos[0][i]+1)/(terms_in_pos_docs + vocabulary)
            
        probability_neg = docs_neg[1]/docs_all
        
        for i in range(len(test_vector)-1):
            if test_vector[i] > 0:
                probability_neg *= (docs_neg[0][i]+1)/(terms_in_neg_docs + vocabulary)
    else:
        
        probability_pos = docs_pos[1]/docs_all
        
        for i in range(len(test_vector)-1):
            if test_vector[i] > 0:
                probability_pos *= docs_pos[0][i]/terms_in_pos_docs
            
        probability_neg = docs_neg[1]/docs_all
        
        for i in range(len(test_vector)-1):
            if test_vector[i] > 0:
                probability_neg *= docs_neg[0][i]/terms_in_neg_docs

    print("+ {}\n- {}".format(probability_pos, probability_neg))
 
 
def get_vectors(documents, terms):
    
    vectors = []
    
    for doc in documents:
        vector = []
        for term in terms:
            vector.append(count_term(term, doc[0]))
        vector.append(doc[1])
        vectors.append(vector)
        
    return vectors


def vector_sum(v1, v2):
    
    sumv = []
    
    if len(v1) == len(v2):
        for i in range(len(v1)):
            sumv.append(v1[i] + v2[i])
    else: 
         raise ValueError('Vectors of different dimensions cannot be added.')
     
    return sumv


def sum_list_of_vectors(vlist):
    
    if len(vlist) > 1:
        vlist[-2] = vector_sum(vlist[-2], vlist[-1])
        vlist.pop()
        return sum_list_of_vectors(vlist)
    else:
        return vlist[0]


def field_sum(vector):
    
    sum = 0
    
    for i in range(len(vector)):
        sum += vector[i]
        
    return sum



if __name__ == "__main__":
    
    terms = [r"\bVerband\b", r"\bStruktur\b", r"\bLehre\b", r"\bKörper\b", r"\bTeilgebiet\b", r"\bPerson(en)?\b", r"\bKrankheit\b", r"\bMedizin\b", r"\bSinne\b"]
    
    to_smoothe = False
    
    if len(sys.argv) > 1 and sys.argv[1] == "smoothed":
        to_smoothe = True

    c = read_corpus_from_file("corpus.txt")
    
    data = get_vectors(c, terms)
    training_data = data[1:]
    test_data = data[0]
    
    predict(test_data, training_data, terms, to_smoothe)
