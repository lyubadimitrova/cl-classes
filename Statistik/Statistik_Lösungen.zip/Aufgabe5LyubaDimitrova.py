# -*- coding: utf-8 -*-
"""

@author: Lyubomira Dimitrova

"""

import re
import numpy as np


'''
General functions
'''

def read_corpus_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as corpus:
        documents = [sent.split("\t") for sent in corpus.read().split("\n") if sent != ""]
    return documents

def get_vectors(data, terms):
    vectors = []
    
    for example in data:
        vector = []
        for term in terms:
            vector.append(len(re.findall(term, example[0])))
            
        if example[1].startswith("+"):
            vectors.append((np.array(vector), 1))
        else: 
            vectors.append((np.array(vector), -1))
            
    return vectors

def sum_list_of_vectors(vlist):
    
    sum = vlist[0]
    for n in vlist[1:]:
        sum = np.add(sum, n)
    return sum


'''
Perceptron functions
'''
def learn_perceptron(training_data, learning_rate=1, n=10):
    
    weight = np.zeros(len(training_data[0][0]))

    for i in range(n):
        for example in training_data:
            
            label = example[1]
            doc = example[0]
            
            if label * np.dot(weight, doc) <= 0:
                weight = weight + learning_rate * label * doc
        
    return weight

def perceptron_score(training_data, test_vector):
    
    weight = learn_perceptron(training_data)
    score = np.dot(np.array(test_vector), weight)

    print("\n\n Perceptron:\n Final weights: {}\n Score on the test data: {} ".format(weight, score))
    if score > 0:
        print(" The test document was classified as positive!!!\n")
    else: 
        print(" The test document was classified as negative.\n")
    

'''
Naive Bayes functions
'''
def naive_bayes(document_vectors, terms):
    
    positive_docs = []
    negative_docs = []
    
    for doc in document_vectors:
        if doc[-1] == 1:
            positive_docs.append(doc[0])
        else:
            negative_docs.append(doc[0])
    
    number_pos_docs = len(positive_docs)
    number_neg_docs = len(negative_docs)
    
    pos_vector = sum_list_of_vectors(positive_docs)
    neg_vector = sum_list_of_vectors(negative_docs)
    
    return (pos_vector, number_pos_docs), (neg_vector, number_neg_docs), len(document_vectors), len(terms)


def nb_predict(test_vector, document_vectors, terms, smoothing):
    
    model = naive_bayes(document_vectors, terms)
    docs_pos = model[0]
    docs_neg = model[1]
    docs_all = model[2]
    vocabulary = model[3]
    
    terms_in_pos_docs = np.sum(docs_pos[0])
    terms_in_neg_docs = np.sum(docs_neg[0])
    
    s = 0
    
    if smoothing == True:
        s = 1
        
    probability_pos = docs_pos[1]/docs_all
    
    for i in range(len(test_vector)):
        count = list(test_vector)[i]
        if count > 0:
            probability_pos *= ((docs_pos[0][i]+s)/(terms_in_pos_docs + s*vocabulary))**count
            
    probability_neg = docs_neg[1]/docs_all
        
    for i in range(len(test_vector)):
        count = list(test_vector)[i]
        if count > 0:
            probability_neg *= ((docs_neg[0][i]+s)/(terms_in_neg_docs + s*vocabulary))**count

    print("\n\n Naive Bayes: \n + {}\n - {}".format(probability_pos, probability_neg))
    if probability_pos > probability_neg:
        print(" The test document was classified as positive.")
    else: 
        print(" The test document was classified as negative.")
    

    
if __name__ == "__main__":
    
    terms = [r"\bVerband\b", r"\bStruktur\b", r"\bLehre\b", r"\bKörper\b", r"\bTeilgebiet\b", r"\bPerson(en)?\b", r"\bKrankheit\b", r"\bMedizin\b", r"\bSinne\b"]

    c = read_corpus_from_file("corpus.txt")
    
    data = get_vectors(c, terms)
    training_data = data[1:]
    test_data = data[0][0]          #test data without label
    
    nb_predict(test_data, training_data, terms, smoothing = True)
    
    perceptron_score(training_data, test_data)
    
    
    
