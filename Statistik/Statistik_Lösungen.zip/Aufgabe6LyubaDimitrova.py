import numpy as np

labels = (0, 1, 2)
label_names = {'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2}

def read_data_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as data:
        documents = [line.split(",") for line in data.read().split("\n") if line != ""]
    return documents

def get_vectors(data):
    return [[[float(x) for x in example[:-1]], label_names[example[-1]]] for example in data]

def multiclass_perceptron(training_data, learning_rate = 1, epochs = 2000):         #because Michi said so
    weights = np.zeros(len(training_data[0][0]) * len(labels)) 
    errors = 0
    for _ in range(epochs):
        for t in training_data:
            predicted_label = label_max_score(t[0], weights)
            if predicted_label != t[1]:
                weights = weights + learning_rate * (phi(t[0], t[1]) - phi(t[0], predicted_label))
                errors += 1
    return weights

def perceptron_accuracy(test_data, weights):
    correctly_labeled = 0
    for t in test_data:
        if label_max_score(t[0], weights) == t[1]:
            correctly_labeled += 1
    return correctly_labeled / len(test_data)

def label_max_score(t, weights):
    score_dict = {}
    for label in labels:
        score_dict[np.dot(weights, phi(t, label))] = label
    return score_dict[max(score_dict.keys())]

def phi(training_example, label):
    fluff = [0] * len(training_example)
    pump_dict = {0: training_example + 2 * fluff, 1: fluff + training_example + fluff, 2: 2 * fluff + training_example}
    return np.array(pump_dict[label])

def add_bias(training_data, bias=-1):
    for t in training_data:
        t[0] = t[0] + [bias]
    return training_data
  
if __name__ == "__main__":
    d = read_data_from_file("iris.data")

    data = get_vectors(d)
    training_data = []
    test_data = []

    for i in range(len(data)):
        if i % 5 == 0:
            test_data.append(data[i])
        else:
            training_data.append(data[i])

    weights = multiclass_perceptron(training_data)
    print("\n Accuracy on the training set:\t", perceptron_accuracy(training_data, weights))
    print(" Accuracy on the test set:\t", perceptron_accuracy(test_data, weights))
    
    biased_training_data = add_bias(training_data)
    biased_test_data = add_bias(test_data)
    weights_biased = multiclass_perceptron(biased_training_data)
    print("\n Accuracy on the training set (w/ bias):\t", perceptron_accuracy(biased_training_data, weights_biased))
    print(" Accuracy on the test set (w/ bias):\t\t", perceptron_accuracy(biased_test_data, weights_biased))
    
    print("\n => Adding a bias had no effect on the test set error :( ")