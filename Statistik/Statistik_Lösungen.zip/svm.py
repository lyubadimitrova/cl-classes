import numpy as np
from random import choice

labels = (0, 1, 2)
label_names = {'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2}

def read_data_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as data:
        documents = [line.split(",") for line in data.read().split("\n") if line != ""]         #data.readlines()?
    return documents

def get_vectors(data):
    return [([float(x) for x in example[:-1]], label_names[example[-1]]) for example in data]

def phi(training_example, label):
    fluff = [0] * len(training_example)
    pump_dict = {0: training_example + 2 * fluff, 1: fluff + training_example + fluff, 2: 2 * fluff + training_example}
    return np.array(pump_dict[label])

def label_max_score(t, weights):
    dict = {}
    for label in labels:
        dict[np.dot(weights, phi(t, label))] = label
    return dict[max(dict.keys())]

def max_score(t, weights):
    dict = {}
    for label in labels:
        dict[np.dot(weights, phi(t, label))] = label
    return max(dict.keys()), dict[max(dict.keys())]

def svm_online(training_data, epochs = 2000, learning_rate = 0.1, regularization = 0.5):
    weights = np.zeros(len(training_data[0][0]) * len(labels))

    for _ in range(1, epochs):
        for t in training_data:
            predicted_label = label_max_score(t[0], weights)
            if np.dot(weights, phi(t[0], t[1])) - np.dot(weights, phi(t[0], predicted_label)) <= 1:
                weights = weights + learning_rate * (phi(t[0], t[1]) - phi(t[0], predicted_label) - regularization * weights)
            else:
                weights = weights - learning_rate * regularization * weights

    print(weights)
    return weights

def svm_batch(training_data, epochs = 2000, learning_rate = 0.1, regularization = 0.5):
    weights = np.zeros(len(training_data[0][0]) * len(labels))

    batch_gradient = [0] * len(weights)

    for n in range(1, epochs):

        for t in training_data:
            step = np.zeros(len(weights))
            predicted_label = label_max_score(t[0], weights)
            if np.dot(weights, phi(t[0], t[1])) - np.dot(weights, phi(t[0], predicted_label)) <= 1:
                step = np.add(step, phi(t[0], t[1]) - phi(t[0], predicted_label) - regularization * weights)
            else:
                step = np.subtract(step, regularization * weights)
            batch_gradient = batch_gradient + learning_rate * step

        weights = weights - batch_gradient / (len(training_data) * n)

    print(weights)
    return weights

def svm_averaged(training_data, epochs = 2000, learning_rate = 0.1, regularization = 0.5):
    weights = np.zeros(len(training_data[0][0]) * len(labels))
    weights_list = [weights]

    for _ in range(1, epochs):
        for t in training_data:
            predicted_label = label_max_score(t[0], weights)
            if np.dot(weights, phi(t[0], t[1])) - np.dot(weights, phi(t[0], predicted_label)) <= 1:
                weights = weights + learning_rate * (phi(t[0], t[1]) - phi(t[0], predicted_label) - regularization * weights)
            else:
                weights = weights - learning_rate * regularization * weights
            weights_list.append(weights)

    print(np.sum(weights_list, 0) / (epochs * len(training_data)))
    return np.sum(weights_list, 0) / (epochs * len(training_data))

def accuracy(weights, test_data):
    correctly_labeled = 0
    for t in test_data:
        if label_max_score(t[0], weights) == t[1]:
            correctly_labeled += 1
    return correctly_labeled / len(test_data)

if __name__ == "__main__":
    d = read_data_from_file("iris.data")

    data = get_vectors(d)
    training_data = []
    test_data = []

    for i in range(len(data)):
        if i % 5 == 0:
            test_data.append(data[i])
        else:
            training_data.append(data[i])

print(accuracy(svm_online(training_data), test_data))                #0.3333333333333333
print(accuracy(svm_batch(training_data), test_data))                #0.3333333333333333
print(accuracy(svm_averaged(training_data), test_data))                #0.3333333333333333

#The weights are different, but the accuracy on the test set remains the same:
'''
[-0.01005276 -0.00490324 -0.00752627 -0.00256846 -0.06747712 -0.03102729
 -0.06129776 -0.02314386  0.07752988  0.03593053  0.06882403  0.02571232]
0.3333333333333333
[ -1.40349253e+08  -9.65563303e+07  -4.11088400e+07  -6.85147333e+06
  -1.67543245e+08  -7.75558527e+07  -1.19936100e+08  -3.73652514e+07
   3.07892497e+08   1.74112183e+08   1.61044940e+08   4.42167248e+07]
0.3333333333333333
[-0.0249867  -0.00333128 -0.05164024 -0.02165563  0.01000034  0.00833162
 -0.00999015 -0.0066615   0.01498636 -0.00500034  0.06163038  0.02831713]
0.3333333333333333
'''

#The low accuracy is likely due to the (small) amount of training data we had, or the fact that the data is not
#linearly separable with a big enough margin.