import numpy as np
from random import choice

labels = (0, 1, 2)
label_names = {'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2}

def read_data_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as data:
        documents = [line.split(",") for line in data.read().split("\n") if line != ""]         #data.readlines()?
    return documents

def get_vectors(data):
    return [([float(x) for x in example[:-1]], label_names[example[-1]]) for example in data]

def phi(training_example, label):
    fluff = [0] * len(training_example)
    pump_dict = {0: training_example + 2 * fluff, 1: fluff + training_example + fluff, 2: 2 * fluff + training_example}
    return np.array(pump_dict[label])

def label_max_score(t, weights):
    dict = {}
    for label in labels:
        dict[np.dot(weights, phi(t, label))] = label
    return dict[max(dict.keys())]

def perceptron_online(training_data, epochs = 2000, learning_rate = 0.1):
    weights = np.zeros(len(training_data[0][0]) * len(labels))

    for _ in range(1, epochs):
        for t in training_data:
            predicted_label = label_max_score(t[0], weights)
            if np.dot(weights, phi(t[0], t[1])) - np.dot(weights, phi(t[0], predicted_label)) <= 0:
                weights = weights + learning_rate * (phi(t[0], t[1]) - phi(t[0], predicted_label))
            # if predicted_label != t[1]:                                #is it the same?
                # weights = weights + learning_rate * (phi(t[0], t[1]) - phi(t[0], predicted_label))

    #print(weights)
    return weights

def perceptron_batch(training_data, epochs = 2000, learning_rate = 0.1):
    weights = batch_gradient = np.zeros(len(training_data[0][0]) * len(labels))

    for n in range(1, epochs):
        for t in training_data:
            step = np.zeros(0)
            predicted_label = label_max_score(t[0], weights)

            if np.dot(weights, phi(t[0], t[1])) - np.dot(weights, phi(t[0], predicted_label)) <= 0:
                step = np.add(0, (phi(t[0], predicted_label) - phi(t[0], t[1])))

            batch_gradient = batch_gradient + learning_rate * step

        weights = weights - batch_gradient / (len(training_data) * n)
    print(weights)
    return weights

def perceptron_averaged(training_data, epochs = 2000, learning_rate = 0.1):
    weights = np.zeros(len(training_data[0][0]) * len(labels))
    weights_list = [weights]

    for _ in range(1, epochs):
        for t in training_data:
            predicted_label = label_max_score(t[0], weights)
            if np.dot(weights, phi(t[0], t[1])) - np.dot(weights, phi(t[0], predicted_label)) <= 0:
                weights = weights + learning_rate * (phi(t[0], t[1]) - phi(t[0], predicted_label))
                weights_list.append(weights)

    #print(np.sum(weights_list, 0) / (epochs * len(training_data)))
    return np.sum(weights_list, 0) / (epochs * len(training_data))

def accuracy(weights, test_data):
    correctly_labeled = 0
    for t in test_data:
        if label_max_score(t[0], weights) == t[1]:
            correctly_labeled += 1
    return correctly_labeled / len(test_data)

if __name__ == "__main__":
    d = read_data_from_file("iris.data")

    data = get_vectors(d)
    training_data = []
    test_data = []

    for i in range(len(data)):
        if i % 5 == 0:
            test_data.append(data[i])
        else:
            training_data.append(data[i])

#print(accuracy(perceptron_online(training_data), test_data))                #0.9666666666666667
print(accuracy(perceptron_batch(training_data), test_data))                #0.9666666666666667
#print(accuracy(perceptron_averaged(training_data), test_data))                #0.9666666666666667

#The weights are different, but the accuracy on the test set remains the same:
'''
[ 11.35  16.31 -21.86 -13.3   12.79   8.69 -12.09 -25.2  -24.14 -25.    33.95
  38.5 ]
0.9666666666666667
[ 1.37933257  3.40091582 -4.63187727 -2.15779185  1.4118576  -0.29884772
 -0.15010175 -1.65069151 -2.79119017 -3.1020681   4.78197902  3.80848336]
0.9666666666666667
[  7.95709421  11.39257417 -15.6455725   -9.14813929   8.808406
   6.58607242  -8.48474371 -16.69589213 -16.76550021 -17.97864658
  24.13031621  25.84403142]
0.9666666666666667
'''