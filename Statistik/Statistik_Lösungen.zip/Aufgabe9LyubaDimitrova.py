import numpy as np

labels = (0, 1, 2)
label_names = {'Iris-setosa': 0, 'Iris-versicolor': 1, 'Iris-virginica': 2}

def read_data_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as data:
        documents = [line.split(",") for line in data.read().split("\n") if line != ""]
    return documents


def get_vectors(data):
    return [[tuple([float(x) for x in example[:-1]]), label_names[example[-1]]] for example in data]


def get_initial_alpha_dict(training_data):
    alpha_dict = {}
    
    for t in training_data:
        for l in labels:
            alpha_dict[(l, t[0])] = 0

    return alpha_dict


def phi(training_example, label):
    fluff = [0] * len(training_example)
    pump_dict = {0: list(training_example) + 2 * fluff, 1: fluff + list(training_example) + fluff, 2: 2 * fluff + list(training_example)}
    return np.array(pump_dict[label])

dictionary={}
def K(par1, par2, par3, par4, power):
    if (par1, par2, par3, par4) not in dictionary:
        dictionary[(par1, par2, par3, par4)] = np.dot(phi(par1, par2), phi(par3, par4)) ** power
    return dictionary[(par1, par2, par3, par4)]


def label_max_score(t, training_data, alpha_dict, power):
    
    sums = [0] * len(labels)
    
    for r in training_data:
        for label in range(3):
            for i in range(3):
                sums[i] += alpha_dict[(label, r[0])] * (K(r[0], r[1], t[0], i, power) - K(r[0], label, t[0], i, power))
            
    return sums.index(max(sums))


def perceptron(training_data, kernel_power, epochs=500):
    
    alpha_dict = get_initial_alpha_dict(training_data)
    
    for _ in range(1, epochs):
        for t in training_data:
            
            predicted_label = label_max_score(t, training_data, alpha_dict, kernel_power)
            
            if predicted_label != t[1]:
                alpha_dict[(predicted_label, t[0])] += 1
    
    return alpha_dict


def accuracy(training_data, alpha_dict, test_data, power):
    correctly_labeled = 0
    
    for t in test_data:

        if label_max_score(t, training_data, alpha_dict, power) == t[1]:
            correctly_labeled += 1
            
    return correctly_labeled / len(test_data)
            
    

if __name__ == "__main__":
    d = read_data_from_file("iris.data")

    data = get_vectors(d)
    training_data = []
    test_data = []

    for i in range(len(data)):
        if i % 5 == 0:
            test_data.append(data[i])
        else:
            training_data.append(data[i])
            
    print('Linear Kernel: ', accuracy(training_data, perceptron(training_data, 1), test_data, 1))
    print('Polynomial Kernel: ', accuracy(training_data, perceptron(training_data, 2), test_data, 2))
