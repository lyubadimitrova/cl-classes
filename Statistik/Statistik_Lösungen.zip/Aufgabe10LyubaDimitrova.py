import numpy as np
import re

def read_corpus_from_file(filename):
    with open(filename, 'r', encoding="utf-8") as corpus:
        documents = [sent.split("\t") for sent in corpus.read().split("\n") if sent != ""]
    return documents


def get_vectors(data, terms):
    vectors = []
    
    for example in data:
        vector = []
        for term in terms:
            vector.append(len(re.findall(term, example[0])))
        vectors.append(vector)
            
    inputs = np.matrix([vector for vector in vectors])
    
    labels = []
    for d in data:
        if d[1].startswith('+'):
            labels.append(1)
        else:
            labels.append(-1)
    outputs = np.transpose(np.matrix(np.array([d for d in labels])))
    
    return inputs, outputs


def sigmoid(x, deriv=False):
    if deriv == True:
        return x * (1 - x)
    return 1 / (1 + np.exp(-x))


def multilayer_perceptron(inputs, outputs, epochs=60000):
    
    np.random.seed(1)
    
    w1_matrix = 2 * np.random.random((9, 10)) - 1
    w2_matrix = 2 * np.random.random((10, 1)) - 1
    
    
    for n in range(epochs):
        
        input_layer = inputs
        hidden_layer = sigmoid(np.dot(input_layer, w1_matrix))
        output_layer = sigmoid(np.dot(hidden_layer, w2_matrix))
        
        output_error = np.array(outputs) - np.array(output_layer)
        output_difference = output_error * sigmoid(np.array(output_layer), deriv=True)
        
        if n % 10000 == 0:
            print("Error: ", np.mean(np.abs(output_error)))

        hidden_error = np.dot(output_difference, w2_matrix.T)
        hidden_difference = hidden_error * sigmoid(np.array(hidden_layer), deriv=True)
        
        w2_matrix += np.dot(np.transpose(hidden_layer), output_difference)
        w1_matrix += np.dot(np.transpose(input_layer), hidden_difference)



if __name__ == '__main__':
    
    terms = [r"\bVerband\b", r"\bStruktur\b", r"\bLehre\b", r"\bKörper\b", r"\bTeilgebiet\b", r"\bPerson(en)?\b", r"\bKrankheit\b", r"\bMedizin\b", r"\bSinne\b"]

    c = read_corpus_from_file("corpus.txt")
    data = get_vectors(c, terms)

    multilayer_perceptron(data[0], data[1])
    
    """
    Error:  0.9156135727280489
    Error:  0.40124654674747495
    Error:  0.40085938971703605
    Error:  0.40069232360985463
    Error:  0.400594192525237
    Error:  0.40052790372395874

    """
    
